import greenfoot.Greenfoot;

public class Crab extends Animal
{
    private final int shootSpeed = 100;
    private int shootCounter = shootSpeed;
    

    public void act()
    {
        shootCounter++;

        tryToEatSandworm();
        keyMove();
        scream();
    }
    
    public void keyMove()
    {
        if (Greenfoot.isKeyDown("left")) 
            turn(-5);
        
        if (Greenfoot.isKeyDown("right"))
            turn(5);
        
        if (Greenfoot.isKeyDown("up")) 
            move();
        
        if (Greenfoot.isKeyDown("down")) 
            move(-3);    
            

        if (Greenfoot.isKeyDown("space") && shootCounter >= shootSpeed) {
            shootCounter = 0;
            Ant ameise = new Ant();
            CrabWorld welt = (CrabWorld)getWorld();
            welt.addObject(ameise, getX(), getY());
            ameise.setRotation(getRotation());
            Greenfoot.playSound("shot.wav");
            getWorld().addObject(new Explosion2(), getX(), getY());
            
        }
    } 

    public void scream()
    {
        if (Greenfoot.isKeyDown("1"))
        Greenfoot.playSound("screamap.wav");
        
        if (Greenfoot.isKeyDown("2"))
        Greenfoot.playSound("moveforward.wav");
        
        if (Greenfoot.isKeyDown("3"))
        Greenfoot.playSound("fire.wav");
        
        if (Greenfoot.isKeyDown("4"))
        Greenfoot.playSound("enemyfront.wav");
    }
    
    
    public void tryToEatSandworm()
    {
        if (canSee(Sandworm.class)) {
            eat(Sandworm.class);
        Greenfoot.playSound("slurp.wav");

        CrabWorld welt = (CrabWorld)getWorld();
        welt.gibZaehler().add(1);

        if (welt.gibZaehler().getValue() == 10)
            Greenfoot.stop();

        }
    }
}
        

    
