import greenfoot.World;

public class CrabWorld extends World
{
    private final Counter zaehler;
    
    
    
    /**
     * Create the crab world (the beach). Our world has a size 
     * of 560x560 cells, where every cell is just 1 pixel.
     */
    public CrabWorld() 
    {
        super(560, 560, 1);
        zaehler = new Counter();
        addObject(zaehler, 100, 50); 
        
        addObject();
    }
    
    
    public void addObject()
    {
        Crab krabbe = new Crab();
        addObject(krabbe, 285, 529);
        krabbe.setRotation(-90);
        
        Lobster Hummer = new Lobster();
        addObject(Hummer, 240, 240);
        
        Lobster Hummer1 = new Lobster();
        addObject(Hummer1, 369, 240);
        
        Lobster Hummer3 = new Lobster();
        addObject(Hummer3, 120, 240);
        
        Sandworm Battery = new Sandworm();
        addObject(Battery, 165, 51);
        
        Sandworm Battery2 = new Sandworm();
        addObject(Battery2, 240, 51);
        
        Sandworm Battery3 = new Sandworm();
        addObject(Battery3, 340, 51);
        
        Sandworm Battery4 = new Sandworm();
        addObject(Battery4, 430, 51);
    }
    
    public Counter gibZaehler()
    {
        return zaehler;
    }
    
}