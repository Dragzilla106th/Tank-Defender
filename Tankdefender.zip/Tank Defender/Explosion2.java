import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.Actor;
import greenfoot.Greenfoot;
import greenfoot.GreenfootImage;
import greenfoot.GreenfootSound;

/**
 * Write a description of class Explosion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Explosion2 extends Actor
{
    private final int maxAge;
    private int age;

    private static GreenfootImage[] frames = new GreenfootImage[] {
            new GreenfootImage("explosion1.png"),
            new GreenfootImage("explosion2.png"),
            new GreenfootImage("explosion3.png"),
            new GreenfootImage("explosion4.png"),
            new GreenfootImage("explosion5.png")
    };

    public Explosion2() {
        this(25);
    }

    public Explosion2(int maxAge) {
        this.maxAge = maxAge;
        this.age = 0;


    }

    @Override
    public void act() {
        age++;

        if (age >= maxAge)
            getWorld().removeObject(this);
    }

    @Override
    public GreenfootImage getImage() {
        return frames[(int)(((float)age / maxAge) * frames.length)];
    }
}
