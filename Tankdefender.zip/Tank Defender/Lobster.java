import greenfoot.Greenfoot;

/**
 * Write a description of class Lobster here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lobster extends Animal
{
    int rotation = 0;

    public void act() {
        turn(-5);
        
        if (canSee(Crab.class))
            eat(Crab.class);

        if (Greenfoot.getRandomNumber(100) < 20);
            turn(Greenfoot.getRandomNumber(21) - 10);

        randomMove();
    }
    
    public void randomMove() {
        if (Greenfoot.getRandomNumber(100) < 20); 
        turn(Greenfoot.getRandomNumber(21) - 10);
        move();
    }

    public void move() {
        setRotation(rotation);
        super.move();
        setRotation(0);
    }

    public void turn(int angle) {
        this.rotation += angle;
    }
}
