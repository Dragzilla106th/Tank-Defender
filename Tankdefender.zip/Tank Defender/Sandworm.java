import greenfoot.*; 
/**
 * Write a description of class Sandworm here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sandworm extends Animal
{
    /**
     * Constructor for objects of class Sandworm
     */
    public Sandworm()
    {
    }

    public void act() {
        turn(1);
    }
}
