import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ant here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */


public class MG extends Animal
{
    public void act() {
        move();
        if (atWorldEdge()) {
            getWorld().removeObject(this);
            return;
        }
        tryToEatLobster();
    }
      
    public void tryToEatLobster() {
        if (canSee(Lobster.class)) {
            getWorld().addObject(new Explosion(), getX(), getY());
            eat(Lobster.class);
            getWorld().removeObject(this);
        }
    }
}
